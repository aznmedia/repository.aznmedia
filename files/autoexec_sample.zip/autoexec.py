# VN Open Playlist - GOC CHIA SE
import xbmc
xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.thongld.vnplaylist/section/2146638719@1zL6Kw4ZGoNcIuW9TAlHWZrNIJbDU5xHTtz-o8vpoJss/%5BCOLOR+white%5D%5BB%5DG%C3%93C+CHIA+S%E1%BA%BA%5B%2FB%5D%5B%2FCOLOR%5D,return)")