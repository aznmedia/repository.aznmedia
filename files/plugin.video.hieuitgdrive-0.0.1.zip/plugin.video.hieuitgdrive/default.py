#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcaddon, os, shutil
from sqlite3 import dbapi2 as db_lib

Addon_ID = xbmcaddon.Addon().getAddonInfo('id')
mysettings = xbmcaddon.Addon(Addon_ID)
home = xbmc.translatePath(mysettings.getAddonInfo('path').decode('utf-8'))
icon = os.path.join(home, 'icon.png')
fanart = os.path.join(home, 'fanart.jpg')

addons_folder = xbmc.translatePath(os.path.join('special://home', 'addons'))
userdata_folder = xbmc.translatePath(os.path.join('special://profile'))

def set_disabled(Addon_ID, data=None):
	KodiVersion = int(xbmc.getInfoLabel("System.BuildVersion")[:2])
	if KodiVersion > 16:
		setit = 0
		if data is None: data = ''
		sql = 'REPLACE INTO installed (addonID,enabled) VALUES(?,?)'
		db_path = os.path.join(userdata_folder, 'Database', 'Addons27.db')
		conn = db_lib.connect(db_path)
		conn.execute(sql, (Addon_ID, setit,))
		conn.commit()
	else:
		pass

def update_addon():
	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')

def remove_addon():
	shutil.rmtree(os.path.join(addons_folder, Addon_ID))
	set_disabled(Addon_ID, data=None)
	update_addon()

def main():
	gdrive_userdata = os.path.join(userdata_folder, 'addon_data', 'plugin.video.gdrive')
	src = os.path.join(addons_folder, 'plugin.video.hieuitgdrive', 'resources', 'settings.xml')
	dst = os.path.join(gdrive_userdata, 'settings.xml')
	try:
		if not os.path.isdir(gdrive_userdata):
			os.mkdir(gdrive_userdata)
		shutil.move(src, dst)
		remove_addon()
		xbmcgui.Dialog().ok('Chúc Mừng', "Đã chuyển HieuIT's settings cho add-on gdrive thành công!")
	except:
		xbmcgui.Dialog().ok('Cảnh Báo', 'Rất tiếc! Đã xảy ra lỗi, vui lòng thử lại.')

if __name__=="__main__":
	main()