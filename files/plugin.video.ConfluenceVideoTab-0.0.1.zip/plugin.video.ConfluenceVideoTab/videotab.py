#!/usr/bin/python
# -*- coding: utf-8 -*-

# Official Kodi add-on repository: http://kodi.wiki/view/Official_add-on_repository
# Official Kodi addons website: https://kodi.tv/addons

from sqlite3 import dbapi2 as db_lib
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import urllib, urllib2, sys, re, os, shutil, base64, time, zipfile

KodiVersion = int(xbmc.getInfoLabel("System.BuildVersion")[:2])
plugin_handle = int(sys.argv[1])

Addon_ID = xbmcaddon.Addon().getAddonInfo('id')
mysettings = xbmcaddon.Addon(Addon_ID)
home = xbmc.translatePath(mysettings.getAddonInfo('path').decode('utf-8'))
icon = os.path.join(home, 'icon.png')
fanart = os.path.join(home, 'fanart.jpg')

addons_folder = xbmc.translatePath(os.path.join('special://home', 'addons'))
userdata_folder = xbmc.translatePath(os.path.join('special://profile'))

def set_enabled(newaddon, data=None):
	if KodiVersion > 16:
		setit = 1
		if data is None: data = ''
		sql = 'REPLACE INTO installed (addonID,enabled) VALUES(?,?)'
		db_path = os.path.join(userdata_folder, 'Database', 'Addons27.db')
		conn = db_lib.connect(db_path)
		conn.execute(sql, (newaddon, setit,))
		conn.commit()
	else:
		pass

def set_disabled(newaddon, data=None):
	if KodiVersion > 16:
		setit = 0
		if data is None: data = ''
		sql = 'REPLACE INTO installed (addonID,enabled) VALUES(?,?)'
		db_path = os.path.join(userdata_folder, 'Database', 'Addons27.db')
		conn = db_lib.connect(db_path)
		conn.execute(sql, (newaddon, setit,))
		conn.commit()
	else:
		pass

def update_addon():
	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')

def remove_addon():
	shutil.rmtree(os.path.join(addons_folder, Addon_ID))
	set_disabled(Addon_ID, data=None)
	update_addon()

def skin_setting(): ##### https://kodi.wiki/view/List_of_built-in_functions #####
	#### These commands will hide (set the setting to true) Weather, Pictures Music buttons on home screen of current skin - Confluence skin #####
	xbmc.executebuiltin("Skin.SetBool(HomeMenuNoWeatherButton)")  
	xbmc.executebuiltin("Skin.SetBool(HomeMenuNoPicturesButton)")
	xbmc.executebuiltin("Skin.SetBool(HomeMenuNoMusicButton)")

def skin_selection(): ##### Bring up Kodi skin selection window #####
	xbmc.executebuiltin('Addon.Default.Set(xbmc.gui.skin)')

def main():
	skin_confluence = os.path.join(addons_folder, 'skin.confluence')
	skin_confluence_userdata = os.path.join(userdata_folder, 'addon_data', 'skin.confluence')
	kodi17 = os.path.join(home, 'resources', 'modified', 'kodi17')
	aznmedia = os.path.join(addons_folder, 'plugin.video.azn.media')
	aznmediafamily = os.path.join(addons_folder, 'plugin.video.azn.mediafamily')
	confluence_source = 'http://mirrors.kodi.tv/addons/krypton/skin.confluence/skin.confluence-3.1.43.zip'  # Official Kodi Confluence skin add-on
	confluence_dst = os.path.join(addons_folder, 'packages', 'skin.confluence-3.1.43.zip')
	if KodiVersion == 17:
		if os.path.isdir(skin_confluence):
			try:
				if not os.path.isdir(skin_confluence_userdata):
					os.mkdir(skin_confluence_userdata)
				if os.path.exists(os.path.join(kodi17, 'Home.xml')):
					shutil.move(os.path.join(kodi17, 'Home.xml'), os.path.join(skin_confluence, '720p', 'Home.xml'))
				if xbmc.getSkinDir() == 'skin.confluence':
					xbmcgui.Dialog().ok('Attention', 'Next, please select other skin than Confluence to continue. Then re-run this add-on.')
					xbmcgui.Dialog().ok('Chú ý', 'Tiếp theo, hãy chọn skin khác hơn Confluence để tiếp tục. Sau đó chạy lại add-on này.')
					skin_selection()
				if xbmc.getSkinDir() != 'skin.confluence':
					if os.path.isdir(aznmedia) and os.path.exists(os.path.join(kodi17, 'adult', 'settings.xml')):
						shutil.move(os.path.join(kodi17, 'adult', 'settings.xml'), os.path.join(skin_confluence_userdata, 'settings.xml'))
					if os.path.isdir(aznmediafamily) and os.path.exists(os.path.join(kodi17, 'nonadult', 'settings.xml')):
						shutil.move(os.path.join(kodi17, 'nonadult', 'settings.xml'), os.path.join(skin_confluence_userdata, 'settings.xml'))
					if not os.path.isdir(aznmedia) and not os.path.isdir(aznmediafamily) and os.path.exists(os.path.join(kodi17, 'neither', 'settings.xml')):
						shutil.move(os.path.join(kodi17, 'neither', 'settings.xml'), os.path.join(skin_confluence_userdata, 'settings.xml'))
					remove_addon()
					xbmcgui.Dialog().ok('Congratulation', 'Successfully completed the change and this add-on has been deleted. Finally, please select Confluence skin to enjoy. Have fun!')
					xbmcgui.Dialog().ok('Chúc Mừng', 'Đã hoàn thành thay đổi và add-on này đã bị xóa. Sau cùng, hãy chọn Confluence skin để thưởng thức. Chúc vui vẻ!')
					skin_selection()
			except:
				xbmcgui.Dialog().ok('Warning', 'Oops! Something went wrong, please try again.')
				xbmcgui.Dialog().ok('Cảnh Báo', 'Rất tiếc! Đã xảy ra lỗi, vui lòng thử lại.')
		else:
			try:
				if os.path.exists(confluence_dst):
					os.remove(confluence_dst)
				urllib.urlretrieve(confluence_source, confluence_dst)
				un_zip_it = zipfile.ZipFile(confluence_dst, 'r')
				un_zip_it.extractall(addons_folder)
				un_zip_it.close()
				set_enabled('skin.confluence', data=None)
				time.sleep(3)
				update_addon()
				time.sleep(3)
				if not os.path.isdir(skin_confluence_userdata):
					os.mkdir(skin_confluence_userdata)
				if os.path.exists(os.path.join(kodi17, 'Home.xml')):
					shutil.move(os.path.join(kodi17, 'Home.xml'), os.path.join(skin_confluence, '720p', 'Home.xml'))
				if os.path.isdir(aznmedia) and os.path.exists(os.path.join(kodi17, 'adult', 'settings.xml')):
					shutil.move(os.path.join(kodi17, 'adult', 'settings.xml'), os.path.join(skin_confluence_userdata, 'settings.xml'))
				if os.path.isdir(aznmediafamily) and os.path.exists(os.path.join(kodi17, 'nonadult', 'settings.xml')):
					shutil.move(os.path.join(kodi17, 'nonadult', 'settings.xml'), os.path.join(skin_confluence_userdata, 'settings.xml'))
				if not os.path.isdir(aznmedia) and not os.path.isdir(aznmediafamily) and os.path.exists(os.path.join(kodi17, 'neither', 'settings.xml')):
					shutil.move(os.path.join(kodi17, 'neither', 'settings.xml'), os.path.join(skin_confluence_userdata, 'settings.xml'))
				remove_addon()
				xbmcgui.Dialog().ok('Congratulation', 'Successfully completed the change and this add-on has been deleted. Finally, please select Confluence skin to enjoy. Have fun!')
				xbmcgui.Dialog().ok('Chúc Mừng', 'Đã hoàn thành thay đổi và add-on này đã bị xóa. Sau cùng, hãy chọn Confluence skin để thưởng thức. Chúc vui vẻ!')
				skin_selection()
			except:
				xbmcgui.Dialog().ok('Warning', 'Oops! Something went wrong, please try again.')
				xbmcgui.Dialog().ok('Cảnh Báo', 'Rất tiếc! Đã xảy ra lỗi, vui lòng thử lại.')
	else:
		remove_addon()
		xbmcgui.Dialog().ok('Warning', 'Sorry, this add-on is for Kodi version 17.x and it has already been deleted.')
		xbmcgui.Dialog().ok('Cảnh Báo', 'Rất tiếc, add-on này dành cho phiên bản Kodx 17.x và add-on này đã bị xóa.')

if __name__=="__main__":
	main()