#!/usr/bin/python
#coding=utf-8

from sqlite3 import dbapi2 as db_lib
import xbmc, xbmcgui, urllib, os, zipfile, shutil

KodiVersion = int(xbmc.getInfoLabel("System.BuildVersion")[:2])

addonfolder = xbmc.translatePath(os.path.join('special://home','addons'))

baseurl = 'https://bitbucket.org/aznmedia/repository.azn.media/raw/7d3d88815f7f4a5b1ceeba1bbb53406637b4866b/'
testerAddonSrc = baseurl + 'plugin.video.link__tester/plugin.video.link__tester-0.0.1.zip'
echoScriptSrc = baseurl + 'script.module.echo/script.module.echo-1.00.003.zip'
urlresolverScriptSrc = baseurl + 'script.module.urlresolver/script.module.urlresolver-4.0.17.zip'

testerAddon = os.path.join(addonfolder,'plugin.video.link__tester')
echoScript = os.path.join(addonfolder,'script.module.echo')
urlresolverScript = os.path.join(addonfolder,'script.module.urlresolver')

testerAddonDst = os.path.join(addonfolder,'plugin.video.link__tester.zip')
echoScriptDst = os.path.join(addonfolder,'script.module.echo.zip')
urlresolverScriptDst = os.path.join(addonfolder,'script.module.urlresolver.zip')

# Replaceable info
mytext = 'Paris By Night 124'
play_media = 'PlayMedia(plugin://plugin.video.link__tester/?link=%s&mode=play_link)'%'https://drive.google.com/file/d/1nCrZJaulRG0LRtqOhFKdCkp_YIOEK1W2/view'

def set_enabled(newaddon, data=None):
	if KodiVersion > 16:
		try:
			setit = 1
			if data is None: data = ''
			sql = 'REPLACE INTO installed (addonID,enabled) VALUES(?,?)'
			db_path = xbmc.translatePath(os.path.join('special://profile', 'Database', 'Addons27.db'))
			conn = db_lib.connect(db_path)
			conn.execute(sql, (newaddon, setit,))
			conn.commit()
		except:
			pass
	else:
		pass

def install_addons(url, tempo, dst):
	urllib.urlretrieve(url, tempo)
	un_zip_it = zipfile.ZipFile(tempo, 'r')
	un_zip_it.extractall(addonfolder)
	un_zip_it.close()
	set_enabled(dst, data=None)
	os.remove(tempo)

def update_play():
	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
	xbmc.sleep(500)
	xbmc.executebuiltin(play_media)

def main():
	d = xbmcgui.Dialog().yesno('autoexec.py', 'Bạn có muốn xem [COLOR yellow][B]%s[/B][/COLOR] không?' % mytext)
	if d:
		if os.path.isdir(testerAddon):
			set_enabled('plugin.video.link__tester', data=None)
			update_play()
		else:
			if os.path.isdir(echoScript):
				pass
			else:
				install_addons(echoScriptSrc, echoScriptDst, 'script.module.echo')
			if os.path.isdir(urlresolverScript):
				pass
			else:
				install_addons(urlresolverScriptSrc, urlresolverScriptDst, 'script.module.urlresolver')
			install_addons(testerAddonSrc, testerAddonDst, 'plugin.video.link__tester')
			update_play()
	else:
		d = xbmcgui.Dialog().yesno('autoexec.py', 'Bạn có muốn [COLOR magenta][B]xoá[/B][/COLOR] mục tự động chạy này không?')
		if d:
			os.remove(xbmc.translatePath(os.path.join('special://profile', 'autoexec.py')))
			xbmcgui.Dialog().ok('autoexec.py', '[COLOR lime][B]Đã xoá xong.[/B][/COLOR] Bạn sẽ không còn thấy mục này hiện lên mỗi khi chạy Kodi.')
		else:
			pass

if __name__=="__main__":
	main()