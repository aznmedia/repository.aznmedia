#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcaddon, os, sys, shutil
from sqlite3 import dbapi2 as db_lib

Addon_ID = xbmcaddon.Addon().getAddonInfo('id')
mysettings = xbmcaddon.Addon(Addon_ID)
home = xbmc.translatePath(mysettings.getAddonInfo('path').decode('utf-8'))
icon = os.path.join(home, 'icon.png')
fanart = os.path.join(home, 'fanart.jpg')

addons_folder = xbmc.translatePath(os.path.join('special://home', 'addons'))

def set_disabled(Addon_ID, data=None):
	KodiVersion = int(xbmc.getInfoLabel("System.BuildVersion")[:2])
	if KodiVersion > 16:
		setit = 0
		if data is None: data = ''
		sql = 'REPLACE INTO installed (addonID,enabled) VALUES(?,?)'
		db_path = os.path.join(userdata_folder, 'Database', 'Addons27.db')
		conn = db_lib.connect(db_path)
		conn.execute(sql, (Addon_ID, setit,))
		conn.commit()
	else:
		pass

def update_addon():
	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')

def skin_selection(): ##### Bring up Kodi skin selection window #####
	xbmc.executebuiltin('Addon.Default.Set(xbmc.gui.skin)')

def main():
	if xbmc.getSkinDir() == 'skin.confluence':
		xbmcgui.Dialog().ok('Chú ý', 'Tiếp theo, chọn skin khác hơn Confluence để tiếp tục.')
		skin_selection()
	if xbmc.getSkinDir() != 'skin.confluence':
		d = xbmcgui.Dialog().yesno('Mod Confluence Skin for Kodi 18', 'Bạn có muốn chỉnh sửa Confluence Skin cho Kodi 18 không?')
		if d:
			src = os.path.join(addons_folder, Addon_ID, 'resources', 'Home.xml')
			dst = os.path.join(addons_folder, 'skin.confluence', '720p' , 'Home.xml')
			try:
				if os.path.isfile(dst):
					os.remove(dst)
				shutil.copy(src, dst)
				xbmcgui.Dialog().ok('Chúc Mừng', 'Đã thành công. Tiếp theo, hãy chọn skin Confluence để hoàn thành việc chuyển đổi.')
				skin_selection()
			except:
				xbmcgui.Dialog().ok('Cảnh Báo', 'Rất tiếc! Đã xảy ra lỗi, vui lòng thử lại.')
		else:
			xbmcgui.Dialog().ok('Mod Confluence Skin for Kodi 18', 'Chào tạm biệt. Chúc bạn luôn vui vẻ!')
			skin_selection()

if __name__=="__main__":
	main()